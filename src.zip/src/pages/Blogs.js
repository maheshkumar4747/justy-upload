const Blogs = () => {
    return <h1>Blog Articles</h1>;
  };
  
  export default Blogs;